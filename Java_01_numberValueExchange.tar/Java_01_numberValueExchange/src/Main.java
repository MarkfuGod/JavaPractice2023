public class Main {
    public static class Swap {
        public static void Swap_1(int a, int b){
            int temp = a;
            a = b;
            b = temp;
            System.out.println("a = " + a + ", b = " + b);
        }
        public static void Swap_2(int a, int b){
            a = a + b; // 把 a b 之和赋给a
            b = a - b; // 把 a b 之差赋给 b -- >> b = a
            a = a - b; // 把 a b 之差赋给 a -- >> a = b
            System.out.println("a = " + a + ", b = " + b);
        }
        public static void Swap_3(int a, int b){
            a = a ^ b ^ (b = a);
            System.out.println("a = " + a + ", b = " + b);
        }
    }
        public static void main(String[] args) {
            Swap.Swap_1(10, 20);
            Swap.Swap_2(10, 20);
            Swap.Swap_3(10, 20);
        }
    }

/*
*使用临时变量的方法：
- 临时变量法
优点：简单易懂，不会出现溢出或类型转换的问题。
缺点：需要额外的空间来存储临时变量，不能用于交换基本类型的值。
使用加法和减法的方法：
- 
优点：不需要额外的空间，可以用于交换基本类型的值。
缺点：可能会出现溢出的问题，如果两个数相差很大或者有一个数是负数。
使用异或运算符的方法：

优点：不需要额外的空间，可以用于交换基本类型的值，不会出现溢出的问题。
缺点：不太直观，需要注意两个数不能相同，否则会变成零。
*/
